/**
 * 
 */
/**
 * 
 */
module Lab5 {
}