package lab5;

public class UserInputValidator {
	public static String validateName(String name) throws InvalidInputException{
		if (name == null || name.trim().isEmpty()) {
			throw new InvalidInputException("Name cannot be empty.");
		}
		return name.trim();
	}
	public static int validateAge(String ageInput) throws InvalidInputException{
		try {
			int age = Integer.parseInt(ageInput);
			if (age < 0) {
				throw new InvalidInputException("Age must not be a negative.");
			}
			return age;
		} catch (NumberFormatException e) {
			throw new InvalidInputException("Age must be a valid number.");
		}
	}
	public static String validateEmail(String email) throws InvalidInputException {
		if (email == null || !email.contains("@") || !(email.endsWith(".com") || email.endsWith(".edu"))) {
			throw new InvalidInputException("Email  must contain '@' and end in '.com' or '.edu'");
		}
		return email;
	}
	public static String validatePhone(String phone) throws InvalidInputException{
		if (phone == null || !phone.matches("\\d{10}")) {
			throw new InvalidInputException("Phone number must be exactly 10 digits.");
		}
		return phone;
	}
}
