package lab5;
import java.util.ArrayList;
import java.util.Scanner;
public class User {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> users = new ArrayList<>();
        String continueChoice;
        do {
        String name = "";
        int age = 0;
        String email = "";
        String phone = "";
        while (true) {
        	try {
        		System.out.print("Enter name: ");
                name = UserInputValidator.validateName(scanner.nextLine());
                break;
            } catch (InvalidInputException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        while (true) {
        	try {
        		System.out.println("Enter age: ");
        		age = UserInputValidator.validateAge(scanner.nextLine());
        		break;
        	} catch (InvalidInputException e) {
        		System.out.println("Error: " + e.getMessage());
        	}
        }
        while (true) {
        	try {
        		System.out.println("Enter email: ");
                email = UserInputValidator.validateEmail(scanner.nextLine());
                break;
        	} catch (InvalidInputException e) {
        		System.out.println("Error: " + e.getMessage());
        	}
        }
        while (true) {
        	try {
        		System.out.println("Enter phone number: ");
        		phone = UserInputValidator.validatePhone(scanner.nextLine());
        		break;
        	} catch (InvalidInputException e) {
        		System.out.println("Error: " + e.getMessage());
        	}
        }
        String userData = "Name: " + name + ", Age: " + age + ", Email: " + email + ", Phone: " + phone;
        users.add(userData);
        System.out.print("\nDo you want to enter another user? (yes/no): ");
        continueChoice = scanner.nextLine();
        } while (continueChoice.equalsIgnoreCase("yes"));
        System.out.println("\nStored users: ");
        for (String user : users) {
        	System.out.println(user);
        }
	}
}
